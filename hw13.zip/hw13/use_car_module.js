const car = require('./my_car');

car.drive();
car.turn(360);
car.break();